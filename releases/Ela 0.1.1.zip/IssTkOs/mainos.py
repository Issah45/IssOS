from tkinter import *

win = Tk()
win.geometry("500x400")

win.mainloop()
