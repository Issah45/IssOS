from tkinter import *
import os, sys

win = Tk()
win.geometry("500x400")

win.mainloop()
